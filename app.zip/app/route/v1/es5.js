const express = require('express');
const router = express.Router();
const ArticleModel = require('../../models/articleModel.js');

router.post('/', function (req, res) {

    // モデル作成．
    const Article = new ArticleModel();

    // データを詰め込む
    Article.updater = req.body.updater;
    Article.hashtag = req.body.hashtag;
    Article.summary = req.body.summary;
    Article.contents = req.body.contents;
    Article.setDate();

    // 保存処理
    Article.save(function (err) {
        if (err) {
            // エラーがあった場合エラーメッセージを返す
            res.send(err);
        } else {
            // エラーがなければ「Success!!」
            res.json({ message: 'Success!!' });
        }
    });
});

router.put('/:id', function (req, res) {

    var articleId = req.params.id;

    UserModel.findById(Userid, function (err, user) {
        if (err) {
            res.send(err);
        } else {

            user.name = req.body.name;
            user.screen_name = req.body.screen_name;
            user.bio = req.body.bio;

            user.save(function (err) {
                if (err) {
                    res.send(err);
                } else {
                    res.json({ message: 'Success!' });
                }
            });
        }
    });
});

router.get('/', function (req, res) {
    ArticleModel.find().then(function (articles) {
        res.json(articles);
    });

    //res.json({'name':'kaz'});
});

router.get('/:id', function (req, res) {

    const Articleid = req.params.id;
    ArticleModel.findById(Articleid, function (err, article) {
        res.json(article);
    });
});

router.delete('/:id', function (req, res) {
    const Articleid = req.params.id;
    ArticleModel.remove({ _id: Articleid }).then(function () {
        res.json({ message: 'Success!!' });
    });
});

//routerをモジュールとして扱う準備
module.exports = router;
